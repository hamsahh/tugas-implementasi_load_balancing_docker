# Laporan

Folder ini digunakan untuk menyimpan file laporan tugas.

Contoh nama file laporan:

```text
Laporan_Load_Balancer_HAMSAH.pdf
```
