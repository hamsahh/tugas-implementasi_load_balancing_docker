# Hasil Pengujian

Folder ini digunakan untuk menyimpan screenshot hasil pengujian.

Screenshot yang disarankan:

1. Hasil `docker compose -f docker-compose.roundrobin.yml up -d --build`
2. Hasil `docker compose -f docker-compose.roundrobin.yml ps`
3. Hasil `./scripts/test-roundrobin.sh`
4. Log `docker logs rr-nginx-lb`
5. Hasil `docker compose -f docker-compose.leastconn.yml up -d --build`
6. Hasil `docker compose -f docker-compose.leastconn.yml ps`
7. Hasil `./scripts/test-leastconn.sh`
8. Log `docker logs lc-nginx-lb`
