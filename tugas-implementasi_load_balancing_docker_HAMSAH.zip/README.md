# Implementasi Load Balancing Menggunakan Docker dan Nginx

Project ini dibuat untuk simulasi **load balancing** menggunakan **Docker Compose**, **Nginx**, dan **3 backend server Flask**. Sistem diuji menggunakan dua algoritma pembagian beban, yaitu **Round Robin** dan **Least Connection**.

## Struktur Folder

```text
tugas-implementasi_load_balancing_docker/
├── backend/
│   ├── app.py
│   ├── Dockerfile
│   └── requirements.txt
├── nginx/
│   ├── roundrobin.conf
│   └── leastconn.conf
├── scripts/
│   ├── test-roundrobin.sh
│   ├── test-leastconn.sh
│   ├── test-roundrobin.bat
│   └── test-leastconn.bat
├── hasil-pengujian/
│   └── README.md
├── laporan/
│   ├── README.md
│   └── Laporan_Load_Balancer_HAMSAH.pdf
├── docker-compose.yml
├── docker-compose.roundrobin.yml
├── docker-compose.leastconn.yml
├── Laporan_Load_Balancer_HAMSAH.pdf
├── CARA_UPLOAD_GITHUB.txt
├── STRUKTUR_FOLDER.txt
└── README.md
```

## Komponen Sistem

1. **Client** mengirim request melalui browser, curl, atau script pengujian.
2. **Nginx Load Balancer** menerima request dari client.
3. Nginx meneruskan request ke salah satu dari 3 backend server.
4. Backend server mengembalikan response dalam format JSON.
5. Hasil response menunjukkan server mana yang menerima request.

Alur sistem:

```text
Client/User
    |
    v
Nginx Load Balancer
    |
    |--- Backend Server 1
    |--- Backend Server 2
    |--- Backend Server 3
```

## Algoritma Round Robin

Round Robin membagi request secara bergiliran ke setiap backend server.

Contoh pembagian request:

```text
Request 1 -> Backend 1
Request 2 -> Backend 2
Request 3 -> Backend 3
Request 4 -> Backend 1
Request 5 -> Backend 2
Request 6 -> Backend 3
```

Jalankan Round Robin:

```bash
docker compose -f docker-compose.roundrobin.yml up -d --build
```

Cek container:

```bash
docker compose -f docker-compose.roundrobin.yml ps
```

Tes melalui browser:

```text
http://localhost:8085/
```

Tes otomatis Linux/Codespaces:

```bash
./scripts/test-roundrobin.sh
```

Tes otomatis Windows:

```bat
scripts\test-roundrobin.bat
```

Lihat log Nginx:

```bash
docker logs rr-nginx-lb
```

Matikan container Round Robin:

```bash
docker compose -f docker-compose.roundrobin.yml down
```

## Algoritma Least Connection

Least Connection mengarahkan request ke backend server yang memiliki jumlah koneksi aktif paling sedikit.

Contoh kondisi:

```text
Backend 1 = 5 koneksi
Backend 2 = 2 koneksi
Backend 3 = 4 koneksi
```

Request berikutnya akan diarahkan ke **Backend 2** karena koneksinya paling sedikit.

Jalankan Least Connection:

```bash
docker compose -f docker-compose.leastconn.yml up -d --build
```

Cek container:

```bash
docker compose -f docker-compose.leastconn.yml ps
```

Tes melalui browser:

```text
http://localhost:8086/
```

Tes otomatis Linux/Codespaces:

```bash
./scripts/test-leastconn.sh
```

Tes otomatis Windows:

```bat
scripts\test-leastconn.bat
```

Lihat log Nginx:

```bash
docker logs lc-nginx-lb
```

Matikan container Least Connection:

```bash
docker compose -f docker-compose.leastconn.yml down
```

## Perbedaan Port

| Algoritma | Port | URL |
|---|---:|---|
| Round Robin | 8085 | http://localhost:8085/ |
| Least Connection | 8086 | http://localhost:8086/ |

## File Penting

| File/Folder | Fungsi |
|---|---|
| `backend/app.py` | Program backend Flask yang memberi response JSON |
| `backend/Dockerfile` | Instruksi build image backend |
| `nginx/roundrobin.conf` | Konfigurasi Nginx untuk algoritma Round Robin |
| `nginx/leastconn.conf` | Konfigurasi Nginx untuk algoritma Least Connection |
| `docker-compose.roundrobin.yml` | Menjalankan simulasi Round Robin |
| `docker-compose.leastconn.yml` | Menjalankan simulasi Least Connection |
| `scripts/` | Script pengujian otomatis |
| `hasil-pengujian/` | Tempat menyimpan screenshot hasil pengujian |
| `laporan/` | Tempat menyimpan file laporan PDF/DOCX |

## Bukti Pengujian yang Perlu Di-screenshot

1. Struktur folder project di GitHub.
2. Isi file `backend/app.py`.
3. Isi file `nginx/roundrobin.conf`.
4. Isi file `nginx/leastconn.conf`.
5. Hasil menjalankan `docker compose -f docker-compose.roundrobin.yml up -d --build`.
6. Hasil menjalankan `docker compose -f docker-compose.roundrobin.yml ps`.
7. Hasil pengujian `./scripts/test-roundrobin.sh`.
8. Hasil menjalankan `docker compose -f docker-compose.leastconn.yml up -d --build`.
9. Hasil menjalankan `docker compose -f docker-compose.leastconn.yml ps`.
10. Hasil pengujian `./scripts/test-leastconn.sh`.

## Kesimpulan

Simulasi ini menunjukkan bahwa Docker dapat digunakan untuk menjalankan beberapa backend server secara terpisah dalam container. Nginx digunakan sebagai load balancer untuk membagi request ke beberapa backend. Algoritma Round Robin membagi request secara bergiliran, sedangkan Least Connection membagi request berdasarkan jumlah koneksi aktif paling sedikit pada backend server.
