@echo off
echo Pengujian Round Robin
for /L %%i in (1,1,9) do (
    echo Request %%i
    curl http://localhost:8085/
    echo.
)
pause
