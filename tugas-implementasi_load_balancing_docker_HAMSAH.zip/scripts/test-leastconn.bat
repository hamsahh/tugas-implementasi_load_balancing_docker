@echo off
echo Pengujian Least Connection
for /L %%i in (1,1,12) do (
    start /B curl http://localhost:8086/slow?delay=2
)
echo Request paralel sudah dikirim.
pause
