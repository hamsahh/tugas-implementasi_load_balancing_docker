# Simulasi Load Balancer Docker: Round Robin dan Least Connection

Project ini berisi simulasi sederhana load balancer menggunakan Docker Compose, Nginx, dan 3 backend Python Flask.

## Isi Project

```text
tugas-implementasi_load_balancing_docker/
├── backend/
│   ├── app.py
│   ├── Dockerfile
│   └── requirements.txt
├── nginx/
│   ├── roundrobin.conf
│   └── leastconn.conf
├── hasil-pengujian/
├── laporan/
├── docker-compose.roundrobin.yml
├── docker-compose.leastconn.yml
└── scripts/
    ├── test-roundrobin.sh
    └── test-leastconn.sh
```

## Algoritma 1: Round Robin

Round Robin membagi request secara bergiliran ke setiap backend server.

Jalankan:

```bash
docker compose -f docker-compose.roundrobin.yml up -d --build
```

Cek container:

```bash
docker compose -f docker-compose.roundrobin.yml ps
```

Tes manual:

```bash
curl http://localhost:8085/
curl http://localhost:8085/
curl http://localhost:8085/
```

Tes otomatis:

```bash
./scripts/test-roundrobin.sh
```

Lihat log Nginx:

```bash
docker logs -f rr-nginx-lb
```

Matikan:

```bash
docker compose -f docker-compose.roundrobin.yml down
```

## Algoritma 2: Least Connection

Least Connection mengarahkan request baru ke backend dengan koneksi aktif paling sedikit.

Jalankan:

```bash
docker compose -f docker-compose.leastconn.yml up -d --build
```

Cek container:

```bash
docker compose -f docker-compose.leastconn.yml ps
```

Tes manual:

```bash
curl http://localhost:8086/slow?delay=2
```

Tes otomatis paralel:

```bash
./scripts/test-leastconn.sh
```

Lihat log Nginx:

```bash
docker logs -f lc-nginx-lb
```

Matikan:

```bash
docker compose -f docker-compose.leastconn.yml down
```

## Urutan Screenshot untuk Laporan

1. Screenshot struktur folder project.
2. Screenshot isi `docker-compose.roundrobin.yml`.
3. Screenshot isi `nginx/roundrobin.conf`.
4. Screenshot perintah `docker compose -f docker-compose.roundrobin.yml up -d --build`.
5. Screenshot `docker compose -f docker-compose.roundrobin.yml ps`.
6. Screenshot hasil `./scripts/test-roundrobin.sh`.
7. Screenshot log `docker logs rr-nginx-lb`.
8. Screenshot isi `docker-compose.leastconn.yml`.
9. Screenshot isi `nginx/leastconn.conf`.
10. Screenshot perintah `docker compose -f docker-compose.leastconn.yml up -d --build`.
11. Screenshot `docker compose -f docker-compose.leastconn.yml ps`.
12. Screenshot hasil `./scripts/test-leastconn.sh`.
13. Screenshot log `docker logs lc-nginx-lb`.

## Kesimpulan Singkat

Round Robin cocok untuk backend dengan spesifikasi dan waktu proses yang relatif sama. Least Connection lebih cocok untuk kondisi request tidak seragam karena memilih server dengan jumlah koneksi aktif paling sedikit.
