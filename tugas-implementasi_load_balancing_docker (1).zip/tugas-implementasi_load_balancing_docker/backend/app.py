import os
import socket
import time
from datetime import datetime
from flask import Flask, request, jsonify

app = Flask(__name__)
SERVER_NAME = os.getenv("SERVER_NAME", socket.gethostname())

@app.route("/")
def home():
    delay = float(request.args.get("delay", "0"))
    if delay > 0:
        time.sleep(delay)
    return jsonify({
        "message": "Response from backend server",
        "server": SERVER_NAME,
        "hostname": socket.gethostname(),
        "path": request.path,
        "delay_seconds": delay,
        "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    })

@app.route("/slow")
def slow():
    delay = float(request.args.get("delay", "2"))
    time.sleep(delay)
    return jsonify({
        "message": "Slow response from backend server",
        "server": SERVER_NAME,
        "hostname": socket.gethostname(),
        "path": request.path,
        "delay_seconds": delay,
        "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    })

@app.route("/health")
def health():
    return {"status": "ok", "server": SERVER_NAME}

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
