#!/usr/bin/env bash
set -e
seq 1 12 | xargs -P12 -I {} sh -c 'curl -s "http://localhost:8086/slow?delay=2" | python -m json.tool | grep "\"server\""'
