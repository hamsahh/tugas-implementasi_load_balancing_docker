#!/usr/bin/env bash
set -e
for i in $(seq 1 9); do
  echo "Request $i"
  curl -s http://localhost:8085/ | python -m json.tool | grep '"server"'
done
